public class Ellipse extends Shape {
    private double majorAxis;
    private double minorAxis;

    public Ellipse(String name, double majorAxis, double minorAxis) {
        super(name);
        this.majorAxis = majorAxis;
        this.minorAxis = minorAxis;
    }

    @Override
    public double calculatePerimeter() {
        return Math.PI * (2 * Math.sqrt((majorAxis * majorAxis + minorAxis * minorAxis) / 2) - Math.abs(majorAxis - minorAxis));
    }

    @Override
    public double calculateArea() {
        return Math.PI * majorAxis * minorAxis;
    }
}
