import java.util.Scanner;

public class CountLetters {
    public static void main(String[] args) {
        int[] counts = new int[26];
        try (Scanner scan = new Scanner(System.in)) {
            System.out.print("Enter a phrase: ");
            String phrase = scan.nextLine().toUpperCase();

            for (int i = 0; i < phrase.length(); i++) {
                try {
                    char c = phrase.charAt(i);
                    if (Character.isLetter(c)) {
                        counts[c - 'A']++;
                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("Non-letter character encountered: " + phrase.charAt(i));
                }
            }
        }

        System.out.println("Letter frequencies:");
        for (int i = 0; i < counts.length; i++) {
            if (counts[i] != 0) {
                System.out.println((char) (i + 'A') + ": " + counts[i]);
            }
        }
    }
}
