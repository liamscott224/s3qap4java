public class EquilateralTriangle extends Triangle {
    public EquilateralTriangle(String name, double side) {
        super(name, side, side, side);
    }

    @Override
    public double calculateArea() {
        // Implement area calculation for an equilateral triangle
        return 0.0;
    }
}
